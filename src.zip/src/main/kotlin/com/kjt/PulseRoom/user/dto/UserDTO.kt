package com.kjt.PulseRoom.user.dto

data class UserDTO(
    val nickname: String,
    val hits: String
) {
}